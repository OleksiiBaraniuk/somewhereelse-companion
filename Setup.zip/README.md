# SomewhereElse Companion

> A D&D companion app for Telegram with mini-games, character management, and campaign tools.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Telegram Bot API](https://img.shields.io/badge/Telegram%20Bot%20API-7.0+-blue.svg)](https://core.telegram.org/bots/api)

---

## 🎲 Features

- **📜 Character Management** - Create and manage D&D characters
- **🎮 Mini Games** - Lockpicking, QTE, and more
- **⚔️ Combat Tracker** - Initiative tracking and combat management
- **🎲 Dice Roller** - Roll dice with modifiers
- **📊 DM Dashboard** - Real-time monitoring of active games
- **🗺️ Campaign Management** - Track multiple campaigns
- **💬 Multi-platform** - Works in Telegram groups and private chats

---

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Telegram account
- GitHub account (for hosting)
- Supabase account (free tier)

### Installation

1. **Clone repository:**
   ```bash
   git clone https://github.com/your-username/somewhereelse-companion.git
   cd somewhereelse-companion
   ```

2. **Install dependencies:**
   ```bash
   pip3 install python-telegram-bot --break-system-packages
   ```

3. **Setup Supabase:**
   - Create account at [supabase.com](https://supabase.com)
   - Create new project
   - Run `database-schema.sql` in SQL Editor
   - Copy Project URL and anon public key

4. **Configure bot:**
   - Edit `bot_v6.py`:
     ```python
     BOT_TOKEN = "your_bot_token_here"
     WEB_APP_URL = "https://your-username.github.io/somewhereelse-companion"
     ```
   - Edit `shared/supabase.js`:
     ```javascript
     const SUPABASE_URL = 'your_supabase_url'
     const SUPABASE_ANON_KEY = 'your_anon_key'
     ```

5. **Deploy web app:**
   - Push to GitHub
   - Enable GitHub Pages in repository settings
   - Source: Deploy from branch `main`

6. **Run bot:**
   ```bash
   python3 bot_v6.py
   ```

📖 **Full setup guide:** See [BOT_SETUP_INSTRUCTIONS.txt](BOT_SETUP_INSTRUCTIONS.txt)

---

## 📱 Usage

### Commands

| Command | Description |
|---------|-------------|
| `/start` | Open main menu |
| `/sheet` | View character sheet |
| `/games` | Browse mini-games |
| `/combat` | Open combat tracker |
| `/help` | Show help |

### Inline Mode

Type `@your_bot_username` in any chat followed by:
- `sheet` - Character sheet
- `games` - Mini games
- `lockpick` - Lockpicking challenge
- `combat` - Combat tracker

### Groups

Add bot to your D&D group and use commands. Each player's data is linked to their Telegram ID, ensuring consistent character management across all chats.

---

## 🏗️ Architecture

```
┌─────────────┐
│   Telegram  │
│   Bot API   │
└──────┬──────┘
       │
┌──────▼──────────────────────┐
│  bot_v6.py (Python)         │
│  - Commands handler         │
│  - Inline mode             │
│  - URL parameters          │
└──────┬──────────────────────┘
       │
┌──────▼──────────────────────┐
│  GitHub Pages (Static Site) │
│  - index.html              │
│  - JavaScript modules      │
│  - Telegram WebApp SDK     │
└──────┬──────────────────────┘
       │
┌──────▼──────────────────────┐
│  Supabase (PostgreSQL)      │
│  - Players & Characters    │
│  - Game results            │
│  - Real-time subscriptions │
└─────────────────────────────┘
```

---

## 📂 Project Structure

```
somewhereelse-companion/
├── bot_v6.py                    # Telegram bot
├── database-schema.sql          # Database schema
├── BOT_SETUP_INSTRUCTIONS.txt   # Setup guide
├── README.md                    # This file
├── index.html                   # Main page
└── shared/
    ├── styles.css               # Global styles
    ├── main.js                  # Main logic
    ├── supabase.js              # Database connection
    └── telegram.js              # Telegram WebApp SDK
```

---

## 🎮 How It Works

### URL Parameters System

When used in **groups**, bot passes user data via URL:

```
https://your-site.com?tg_user_id=123&tg_first_name=John&tg_username=john_doe
```

The web app:
1. Reads URL parameters (or Telegram WebApp data)
2. Creates/finds player in Supabase
3. Links character to Telegram ID
4. Ensures consistent data across all platforms

### Private Chats vs Groups

**Private Chats:**
- Uses Telegram WebApp API
- Opens inside Telegram
- Better user experience

**Groups:**
- Uses URL buttons with parameters
- Opens in browser
- Works with multiple players simultaneously

---

## 🔧 Development

### Tech Stack

- **Frontend:** Vanilla JavaScript, HTML5, CSS3
- **Backend:** Supabase (PostgreSQL + Real-time)
- **Bot:** Python with `python-telegram-bot`
- **Hosting:** GitHub Pages (free)
- **Database:** Supabase (free tier: 500MB, 50K MAU)

### Database Schema

Key tables:
- `players` - Telegram users
- `characters` - Player characters
- `campaigns` - D&D campaigns
- `game_results` - Mini-game results
- `active_games` - Real-time game monitoring
- `dice_rolls` - Dice roll history

Full schema: [database-schema.sql](database-schema.sql)

---

## 🚀 Deployment

### Bot Hosting Options

**Option 1: Local (Development)**
```bash
python3 bot_v6.py
```

**Option 2: PythonAnywhere (Free)**
- 24/7 uptime
- Restart every 3 months
- [pythonanywhere.com](https://pythonanywhere.com)

**Option 3: Railway (Free tier)**
- Auto-deploy from GitHub
- Environment variables
- [railway.app](https://railway.app)

**Option 4: VPS with systemd**
```bash
sudo systemctl enable companion-bot
sudo systemctl start companion-bot
```

---

## 📝 Roadmap

### Phase 1: MVP ✅
- [x] Database schema
- [x] Main page UI
- [x] Character creation
- [x] Telegram bot with commands
- [x] Inline mode
- [x] URL parameters system

### Phase 2: Core Features 🚧
- [ ] Full character sheet page
- [ ] Combat tracker with initiative
- [ ] Dice roller with modifiers
- [ ] Inventory management
- [ ] Campaign features system

### Phase 3: Advanced 🔮
- [ ] DM Dashboard (real-time)
- [ ] Desktop app (Electron)
- [ ] Mobile app (React Native)
- [ ] Virtual Tabletop (Roll20 alternative)

---

## 🤝 Contributing

This is a personal project, but suggestions and feedback are welcome!

### How to Contribute

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Credits

**Idea:** Baraniuk  
**Code:** Claude (Anthropic AI Assistant)

This project was collaboratively developed through conversation between a human game master and an AI assistant. The human provided the vision, game design, testing, and creative direction, while the AI handled implementation, technical architecture, and code generation.

---

## 📞 Support

- **Issues:** [GitHub Issues](https://github.com/your-username/somewhereelse-companion/issues)
- **Documentation:** [BOT_SETUP_INSTRUCTIONS.txt](BOT_SETUP_INSTRUCTIONS.txt)
- **Telegram Bot API:** [Official Docs](https://core.telegram.org/bots)
- **Supabase Docs:** [supabase.com/docs](https://supabase.com/docs)

---

## ⚠️ Disclaimer

This is a hobby project for tabletop RPG enthusiasts. Not affiliated with Wizards of the Coast or D&D.

---

## 🌟 Star History

If you find this project useful, consider giving it a star! ⭐

---

**Last updated:** March 2026  
**Version:** 6.0  
**Status:** Active Development
