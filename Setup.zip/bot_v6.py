"""
SomewhereElse Companion - Telegram Bot v6
Бот для D&D міні-ігор та персонажів
ВСІ команди передають параметри користувача в URL
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo, InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import Application, CommandHandler, ContextTypes, InlineQueryHandler
import logging
from uuid import uuid4

# ================================================
# НАЛАШТУВАННЯ
# ================================================

# TODO: Замініть на ваш токен з @BotFather
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# TODO: Замініть на ваш URL GitHub Pages
WEB_APP_URL = "https://YOUR_USERNAME.github.io/somewhereelse-companion"

# Логування
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ================================================
# КОМАНДИ
# ================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /start - Головне меню"""
    
    # Перевіряємо чи це група
    is_group = update.effective_chat.type in ["group", "supergroup"]
    
    # Отримуємо дані користувача
    user = update.effective_user
    user_params = f"?tg_user_id={user.id}&tg_first_name={user.first_name or ''}&tg_username={user.username or ''}"
    
    if is_group:
        # В групах - URL кнопка з параметрами
        keyboard = [[
            InlineKeyboardButton("🎲 Відкрити Companion", url=f"{WEB_APP_URL}{user_params}")
        ]]
    else:
        # В особистих чатах - Web App кнопка
        keyboard = [[
            InlineKeyboardButton("🎲 Відкрити Companion", web_app=WebAppInfo(url=WEB_APP_URL))
        ]]
    
    welcome_text = (
        "🎲 *Вітаю в Adventurer's Companion!*\n\n"
        "Ваш компаньйон для D&D пригод:\n"
        "• 📜 Лист персонажа\n"
        "• 🎮 Міні-ігри\n"
        "• ⚔️ Combat tracker\n"
        "• 🎲 Кидки кубиків\n\n"
        "Натисніть кнопку нижче щоб почати!"
    )
    
    await update.message.reply_text(
        welcome_text,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    logger.info(f"User {update.effective_user.id} used /start in {'group' if is_group else 'private'}")


async def sheet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /sheet - Лист персонажа"""
    
    # Перевіряємо чи це група
    is_group = update.effective_chat.type in ["group", "supergroup"]
    
    # Отримуємо дані користувача
    user = update.effective_user
    user_params = f"?tg_user_id={user.id}&tg_first_name={user.first_name or ''}&tg_username={user.username or ''}"
    
    if is_group:
        # В групах - URL кнопка з параметрами користувача
        keyboard = [[
            InlineKeyboardButton(
                "📋 Відкрити Character Sheet",
                url=f"{WEB_APP_URL}/character-sheet.html{user_params}"
            )
        ]]
    else:
        # В особистих чатах - Web App кнопка
        keyboard = [[
            InlineKeyboardButton(
                "📋 Відкрити Character Sheet",
                web_app=WebAppInfo(url=f"{WEB_APP_URL}/character-sheet.html")
            )
        ]]
    
    await update.message.reply_text(
        "📜 *Лист персонажа*\n\nНатисніть кнопку щоб переглянути свого персонажа",
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    logger.info(f"User {update.effective_user.id} used /sheet in {'group' if is_group else 'private'}")


async def games(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /games - Міні-ігри"""
    
    # Перевіряємо чи це група
    is_group = update.effective_chat.type in ["group", "supergroup"]
    
    # Отримуємо дані користувача
    user = update.effective_user
    user_params = f"?tg_user_id={user.id}&tg_first_name={user.first_name or ''}&tg_username={user.username or ''}"
    
    if is_group:
        # В групах - URL кнопки з параметрами
        keyboard = [
            [InlineKeyboardButton("🔒 Lockpicking", url=f"{WEB_APP_URL}/games/lockpicking/index.html{user_params}")],
            [InlineKeyboardButton("⚡ QTE", url=f"{WEB_APP_URL}/games/qte/index.html{user_params}")],
            [InlineKeyboardButton("🎮 Всі ігри", url=f"{WEB_APP_URL}{user_params}")]
        ]
    else:
        # В особистих чатах - Web App кнопки
        keyboard = [
            [InlineKeyboardButton("🔒 Lockpicking", web_app=WebAppInfo(url=f"{WEB_APP_URL}/games/lockpicking/index.html"))],
            [InlineKeyboardButton("⚡ QTE", web_app=WebAppInfo(url=f"{WEB_APP_URL}/games/qte/index.html"))],
            [InlineKeyboardButton("🎮 Всі ігри", web_app=WebAppInfo(url=WEB_APP_URL))]
        ]
    
    await update.message.reply_text(
        "🎮 *Міні-ігри*\n\nОберіть гру:",
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    logger.info(f"User {update.effective_user.id} used /games in {'group' if is_group else 'private'}")


async def combat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /combat - Combat Tracker"""
    
    # Перевіряємо чи це група
    is_group = update.effective_chat.type in ["group", "supergroup"]
    
    # Отримуємо дані користувача
    user = update.effective_user
    user_params = f"?tg_user_id={user.id}&tg_first_name={user.first_name or ''}&tg_username={user.username or ''}"
    
    if is_group:
        # В групах - URL кнопка з параметрами
        keyboard = [[
            InlineKeyboardButton("⚔️ Відкрити Combat Tracker", url=f"{WEB_APP_URL}/combat.html{user_params}")
        ]]
    else:
        # В особистих чатах - Web App кнопка
        keyboard = [[
            InlineKeyboardButton("⚔️ Відкрити Combat Tracker", web_app=WebAppInfo(url=f"{WEB_APP_URL}/combat.html"))
        ]]
    
    await update.message.reply_text(
        "⚔️ *Combat Tracker*\n\nВідстежуйте ініціативу та стан персонажів",
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    logger.info(f"User {update.effective_user.id} used /combat in {'group' if is_group else 'private'}")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /help - Довідка"""
    
    help_text = (
        "📖 *Доступні команди:*\n\n"
        "/start - Головне меню\n"
        "/sheet - 📜 Лист персонажа\n"
        "/games - 🎮 Міні-ігри\n"
        "/combat - ⚔️ Combat Tracker\n"
        "/help - 📖 Ця довідка\n\n"
        "_Бот працює в групах та особистих чатах!_\n\n"
        "💡 *Inline Mode:*\n"
        "Напишіть `@botname sheet` в будь-якому чаті!"
    )
    
    await update.message.reply_text(
        help_text,
        parse_mode='Markdown'
    )
    
    logger.info(f"User {update.effective_user.id} used /help")


# ================================================
# INLINE MODE
# ================================================

async def inline_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обробка inline запитів
    Гравці можуть писати: @your_bot sheet
    """
    query = update.inline_query.query.lower().strip()
    
    # Отримуємо дані користувача для URL параметрів
    user = update.inline_query.from_user
    user_params = f"?tg_user_id={user.id}&tg_first_name={user.first_name or ''}&tg_username={user.username or ''}"
    
    results = []
    
    # Пошук по запиту
    if not query or "sheet" in query or "лист" in query:
        results.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="📜 Character Sheet",
                description="Відкрити лист персонажа",
                input_message_content=InputTextMessageContent(
                    "📜 *Лист персонажа*\n\nНатисніть кнопку нижче:",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "📋 Відкрити Character Sheet",
                        url=f"{WEB_APP_URL}/character-sheet.html{user_params}"
                    )
                ]])
            )
        )
    
    if not query or "game" in query or "ігр" in query or "lock" in query:
        results.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="🎮 Mini Games",
                description="Міні-ігри та активності",
                input_message_content=InputTextMessageContent(
                    "🎮 *Міні-ігри*\n\nОберіть гру:",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔒 Lockpicking", url=f"{WEB_APP_URL}/games/lockpicking/index.html{user_params}")],
                    [InlineKeyboardButton("⚡ QTE", url=f"{WEB_APP_URL}/games/qte/index.html{user_params}")],
                    [InlineKeyboardButton("🎮 Всі ігри", url=f"{WEB_APP_URL}{user_params}")]
                ])
            )
        )
    
    if not query or "lockpick" in query or "lock" in query or "відмичк" in query:
        results.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="🔒 Lockpicking Challenge",
                description="Гра на відкриття замків",
                input_message_content=InputTextMessageContent(
                    "🔒 *Lockpicking Challenge*\n\nВідкрийте замок!",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "🔒 Грати в Lockpicking",
                        url=f"{WEB_APP_URL}/games/lockpicking/index.html{user_params}"
                    )
                ]])
            )
        )
    
    if not query or "qte" in query or "react" in query:
        results.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="⚡ Quick Time Event",
                description="Перевірте свою реакцію",
                input_message_content=InputTextMessageContent(
                    "⚡ *Quick Time Event*\n\nПеревірте реакцію!",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "⚡ Грати в QTE",
                        url=f"{WEB_APP_URL}/games/qte/index.html{user_params}"
                    )
                ]])
            )
        )
    
    if not query or "combat" in query or "бій" in query or "бой" in query:
        results.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="⚔️ Combat Tracker",
                description="Відстежування бою",
                input_message_content=InputTextMessageContent(
                    "⚔️ *Combat Tracker*\n\nВідстежуйте ініціативу та стан персонажів",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "⚔️ Відкрити Combat Tracker",
                        url=f"{WEB_APP_URL}/combat.html{user_params}"
                    )
                ]])
            )
        )
    
    if not query:
        # Показати головне меню якщо нічого не введено
        results.insert(0, 
            InlineQueryResultArticle(
                id=str(uuid4()),
                title="🎲 Adventurer's Companion",
                description="Головне меню",
                input_message_content=InputTextMessageContent(
                    "🎲 *Adventurer's Companion*\n\nВаш компаньйон для D&D пригод!",
                    parse_mode='Markdown'
                ),
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(
                        "🎲 Відкрити Companion",
                        url=f"{WEB_APP_URL}{user_params}"
                    )
                ]])
            )
        )
    
    await update.inline_query.answer(results, cache_time=10)
    logger.info(f"User {update.inline_query.from_user.id} used inline query: '{query}'")


# ================================================
# ОБРОБКА ПОМИЛОК
# ================================================

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обробка помилок"""
    logger.error(f"Update {update} caused error {context.error}")


# ================================================
# ГОЛОВНА ФУНКЦІЯ
# ================================================

def main():
    """Запуск бота"""
    
    # Перевірка токена
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ ПОМИЛКА: Замініть BOT_TOKEN на ваш токен")
        return
    
    # Створити Application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Додати обробники команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("sheet", sheet))
    application.add_handler(CommandHandler("games", games))
    application.add_handler(CommandHandler("combat", combat))
    application.add_handler(CommandHandler("help", help_command))
    
    # Додати inline mode обробник
    application.add_handler(InlineQueryHandler(inline_query))
    
    # Обробник помилок
    application.add_error_handler(error_handler)
    
    # Запустити бота
    print("=" * 60)
    print("🤖 Bot v6 - ВСІ команди з параметрами користувача!")
    print("=" * 60)
    print("✅ Готовий до роботи!")
    print("💡 Inline Mode: @botname sheet")
    print("📝 Команди: /start /sheet /games /combat")
    print("⏸️  Ctrl+C щоб зупинити")
    print("=" * 60)
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()

# ============================================================
# Credits
# ============================================================
# Idea: Baraniuk
# Code: Claude (Anthropic AI Assistant)
# ============================================================
