-- ================================================
-- SomewhereElse Companion - Database Schema
-- ================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ================================================
-- 1. PLAYERS (Гравці)
-- ================================================
CREATE TABLE players (
  telegram_id BIGINT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Статистика
  total_games INTEGER DEFAULT 0,
  total_wins INTEGER DEFAULT 0,
  
  -- Налаштування
  preferences JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_players_username ON players(username);

-- ================================================
-- 2. CHARACTERS (Персонажі)
-- ================================================
CREATE TABLE characters (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  player_id BIGINT REFERENCES players(telegram_id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  
  -- Базова інформація
  class TEXT,
  race TEXT,
  level INTEGER DEFAULT 1,
  experience INTEGER DEFAULT 0,
  
  -- Характеристики (D&D stats)
  strength INTEGER DEFAULT 10,
  dexterity INTEGER DEFAULT 10,
  constitution INTEGER DEFAULT 10,
  intelligence INTEGER DEFAULT 10,
  wisdom INTEGER DEFAULT 10,
  charisma INTEGER DEFAULT 10,
  
  -- Бойові характеристики
  hp_current INTEGER DEFAULT 20,
  hp_max INTEGER DEFAULT 20,
  armor_class INTEGER DEFAULT 10,
  initiative_bonus INTEGER DEFAULT 0,
  speed INTEGER DEFAULT 30,
  
  -- Додаткові дані
  background TEXT,
  alignment TEXT,
  avatar_url TEXT,
  
  -- Повний лист персонажа (JSON для гнучкості)
  character_sheet JSONB DEFAULT '{}'::jsonb,
  -- {
  --   "proficiencies": [],
  --   "languages": [],
  --   "equipment": [],
  --   "spells": [],
  --   "features": [],
  --   "notes": ""
  -- }
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_characters_player ON characters(player_id);
CREATE INDEX idx_characters_active ON characters(is_active);

-- ================================================
-- 3. CAMPAIGNS (Кампанії)
-- ================================================
CREATE TABLE campaigns (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  dm_id BIGINT REFERENCES players(telegram_id),
  
  name TEXT NOT NULL,
  description TEXT,
  campaign_type TEXT, -- 'pirates', 'stalker', 'fantasy', 'custom'
  
  -- Telegram інтеграція
  chat_id BIGINT,
  topic_id INTEGER,
  
  -- Campaign Features (динамічні можливості)
  features JSONB DEFAULT '[]'::jsonb,
  -- [
  --   {
  --     "id": "ship_customization",
  --     "name": "Ship Customization", 
  --     "icon": "🚢",
  --     "enabled": true
  --   }
  -- ]
  
  -- Налаштування
  settings JSONB DEFAULT '{}'::jsonb,
  -- {
  --   "allow_pvp": false,
  --   "difficulty": "normal",
  --   "homebrew_rules": []
  -- }
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed', 'archived'))
);

CREATE INDEX idx_campaigns_dm ON campaigns(dm_id);
CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_chat ON campaigns(chat_id);

-- ================================================
-- 4. CAMPAIGN PARTICIPANTS (Учасники кампанії)
-- ================================================
CREATE TABLE campaign_participants (
  campaign_id UUID REFERENCES campaigns(id) ON DELETE CASCADE,
  character_id UUID REFERENCES characters(id) ON DELETE CASCADE,
  
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Статус в кампанії
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'left')),
  
  -- Нотатки DM про персонажа в цій кампанії
  dm_notes TEXT,
  
  PRIMARY KEY (campaign_id, character_id)
);

CREATE INDEX idx_participants_campaign ON campaign_participants(campaign_id);
CREATE INDEX idx_participants_character ON campaign_participants(character_id);

-- ================================================
-- 5. GAME SESSIONS (Ігрові сесії)
-- ================================================
CREATE TABLE game_sessions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  campaign_id UUID REFERENCES campaigns(id) ON DELETE CASCADE,
  
  session_number INTEGER,
  session_name TEXT,
  
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  
  -- Де відбувається сесія
  chat_id BIGINT,
  topic_id INTEGER,
  
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed'))
);

CREATE INDEX idx_sessions_campaign ON game_sessions(campaign_id);
CREATE INDEX idx_sessions_status ON game_sessions(status);

-- ================================================
-- 6. GAME RESULTS (Результати міні-ігор)
-- ================================================
CREATE TABLE game_results (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  session_id UUID REFERENCES game_sessions(id) ON DELETE SET NULL,
  player_id BIGINT REFERENCES players(telegram_id),
  character_id UUID REFERENCES characters(id) ON DELETE SET NULL,
  
  game_type TEXT NOT NULL CHECK (game_type IN ('lockpicking', 'qte', 'archery', 'custom')),
  
  -- Загальні дані
  success BOOLEAN NOT NULL,
  score INTEGER,
  duration_seconds INTEGER,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Специфічні дані для кожної гри (JSON)
  game_data JSONB DEFAULT '{}'::jsonb
  -- Lockpicking: {
  --   "sleight_of_hand_modifier": 5,
  --   "total_rings": 7,
  --   "rings_completed": 7,
  --   "lockpicks_total": 5,
  --   "lockpicks_used": 3
  -- }
  -- QTE: {
  --   "total_rounds": 10,
  --   "successful_rounds": 8,
  --   "average_reaction_time": 450
  -- }
);

CREATE INDEX idx_results_player ON game_results(player_id);
CREATE INDEX idx_results_character ON game_results(character_id);
CREATE INDEX idx_results_session ON game_results(session_id);
CREATE INDEX idx_results_game_type ON game_results(game_type);
CREATE INDEX idx_results_created ON game_results(created_at DESC);

-- ================================================
-- 7. ACTIVE GAMES (Активні ігри для real-time моніторингу DM)
-- ================================================
CREATE TABLE active_games (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  session_id UUID REFERENCES game_sessions(id) ON DELETE CASCADE,
  player_id BIGINT REFERENCES players(telegram_id),
  character_id UUID REFERENCES characters(id) ON DELETE SET NULL,
  
  game_type TEXT NOT NULL,
  
  started_at TIMESTAMPTZ DEFAULT NOW(),
  last_action_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Lockpicking specific
  lockpicking_current_stage INTEGER,
  lockpicking_total_stages INTEGER,
  lockpicking_lockpicks_left INTEGER,
  
  -- QTE specific
  qte_current_round INTEGER,
  qte_total_rounds INTEGER,
  qte_successful_rounds INTEGER,
  
  -- Загальні метадані
  metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_active_games_session ON active_games(session_id);
CREATE INDEX idx_active_games_player ON active_games(player_id);
CREATE INDEX idx_active_games_character ON active_games(character_id);
CREATE INDEX idx_active_games_last_action ON active_games(last_action_at DESC);

-- ================================================
-- 8. DICE ROLLS (Історія кидків кубиків)
-- ================================================
CREATE TABLE dice_rolls (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  session_id UUID REFERENCES game_sessions(id) ON DELETE CASCADE,
  character_id UUID REFERENCES characters(id) ON DELETE SET NULL,
  
  roll_type TEXT, -- 'attack', 'save', 'skill', 'damage', 'custom'
  dice_formula TEXT NOT NULL, -- '1d20+5', '2d6+3'
  result INTEGER NOT NULL,
  
  -- Деталі кидка
  individual_rolls JSONB, -- [12, 5, 3] для 3d6
  modifiers JSONB, -- {"strength": 3, "proficiency": 2}
  
  -- Контекст
  context TEXT, -- 'Stealth check', 'Attack with longsword'
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dice_rolls_session ON dice_rolls(session_id);
CREATE INDEX idx_dice_rolls_character ON dice_rolls(character_id);

-- ================================================
-- TRIGGERS (Автоматичні оновлення)
-- ================================================

-- Trigger для оновлення updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_players_updated_at
  BEFORE UPDATE ON players
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_characters_updated_at
  BEFORE UPDATE ON characters
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at
  BEFORE UPDATE ON campaigns
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger для оновлення статистики гравця
CREATE OR REPLACE FUNCTION update_player_stats()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE players
  SET 
    total_games = total_games + 1,
    total_wins = total_wins + CASE WHEN NEW.success THEN 1 ELSE 0 END
  WHERE telegram_id = NEW.player_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_player_stats_trigger
  AFTER INSERT ON game_results
  FOR EACH ROW
  EXECUTE FUNCTION update_player_stats();

-- ================================================
-- ROW LEVEL SECURITY (Безпека)
-- ================================================

-- Увімкнути RLS на всіх таблицях
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE characters ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE active_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE dice_rolls ENABLE ROW LEVEL SECURITY;

-- Політики для players
CREATE POLICY "Players can read all players"
  ON players FOR SELECT
  USING (true);

CREATE POLICY "Players can update own data"
  ON players FOR UPDATE
  USING (telegram_id = (current_setting('request.jwt.claims', true)::json->>'telegram_id')::bigint);

CREATE POLICY "Players can insert own data"
  ON players FOR INSERT
  WITH CHECK (true);

-- Політики для characters
CREATE POLICY "Anyone can read characters"
  ON characters FOR SELECT
  USING (true);

CREATE POLICY "Players can insert own characters"
  ON characters FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Players can update own characters"
  ON characters FOR UPDATE
  USING (player_id = (current_setting('request.jwt.claims', true)::json->>'telegram_id')::bigint);

-- Політики для campaigns
CREATE POLICY "Anyone can read campaigns"
  ON campaigns FOR SELECT
  USING (true);

CREATE POLICY "Anyone can manage campaigns"
  ON campaigns
  USING (true);

-- Політики для game_results
CREATE POLICY "Anyone can insert game results"
  ON game_results FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can read game results"
  ON game_results FOR SELECT
  USING (true);

-- Політики для active_games
CREATE POLICY "Anyone can manage active games"
  ON active_games
  USING (true);

-- Політики для dice_rolls
CREATE POLICY "Anyone can read dice rolls"
  ON dice_rolls FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert dice rolls"
  ON dice_rolls FOR INSERT
  WITH CHECK (true);

-- ================================================
-- SEED DATA (Тестові дані)
-- ================================================

-- Приклад DM
INSERT INTO players (telegram_id, username, first_name) VALUES
(123456789, 'dm_master', 'Dungeon Master');

-- Приклад тестової кампанії
INSERT INTO campaigns (dm_id, name, description, campaign_type, features) VALUES
(123456789, 
 'Pirates of the Caribbean Seas', 
 'High seas adventure with ship battles and treasure hunting',
 'pirates',
 '[
   {"id": "ship_custom", "name": "Ship Customization", "icon": "🚢", "enabled": true},
   {"id": "port_trade", "name": "Port Trading", "icon": "⚓", "enabled": true},
   {"id": "naval_combat", "name": "Naval Combat", "icon": "💣", "enabled": true}
 ]'::jsonb
);

-- ================================================
-- VIEWS (Зручні запити)
-- ================================================

-- View для активних персонажів з інформацією про гравця
CREATE VIEW active_characters_with_players AS
SELECT 
  c.*,
  p.username,
  p.first_name,
  p.last_name
FROM characters c
JOIN players p ON c.player_id = p.telegram_id
WHERE c.is_active = true;

-- View для статистики кампаній
CREATE VIEW campaign_stats AS
SELECT 
  c.id as campaign_id,
  c.name as campaign_name,
  COUNT(DISTINCT cp.character_id) as total_players,
  COUNT(DISTINCT gs.id) as total_sessions,
  COUNT(DISTINCT gr.id) as total_minigames_played
FROM campaigns c
LEFT JOIN campaign_participants cp ON c.id = cp.campaign_id
LEFT JOIN game_sessions gs ON c.id = gs.campaign_id
LEFT JOIN game_results gr ON gs.id = gr.session_id
GROUP BY c.id, c.name;

-- ================================================
-- COMMENTS (Документація)
-- ================================================

COMMENT ON TABLE players IS 'Гравці (Telegram користувачі)';
COMMENT ON TABLE characters IS 'Персонажі гравців (може бути кілька на одного гравця)';
COMMENT ON TABLE campaigns IS 'D&D кампанії (ведуться DM)';
COMMENT ON TABLE campaign_participants IS 'Зв''язок персонажів з кампаніями';
COMMENT ON TABLE game_sessions IS 'Окремі ігрові сесії в рамках кампанії';
COMMENT ON TABLE game_results IS 'Результати міні-ігор';
COMMENT ON TABLE active_games IS 'Активні ігри зараз (для real-time моніторингу DM)';
COMMENT ON TABLE dice_rolls IS 'Історія всіх кидків кубиків';


-- ============================================================
-- Credits
-- ============================================================
-- Idea: Baraniuk
-- Code: Claude (Anthropic AI Assistant)
-- ============================================================
